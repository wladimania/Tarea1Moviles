package com.example.myapplicationdbmoviles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void dbenviar(View dbcreate){
        Intent intent=new Intent(MainActivity.this, MainActivity.class);
        EditText txtwert=(EditText)findViewById(R.id.iddamla);
        EditText txtmeni=(EditText)findViewById(R.id.iddamla1);
        EditText txtbent=(EditText)findViewById(R.id.iddamla2);
        EditText txtmart=(EditText) findViewById(R.id.iddamla3);
        EditText txtpant=(EditText)findViewById(R.id.iddamla5);
        EditText txtgis=(EditText)findViewById(R.id.iddamla6);

        Bundle d=new Bundle();
        d.putString("NOMBRE",txtwert.getText().toString());
        intent.putExtras(d);
        startActivity(intent);
    }
}